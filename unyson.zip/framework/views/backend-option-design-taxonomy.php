<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $id
 * @var  array $option
 * @var  mixed $data
 */

/**
 * https://github.com/ThemeFuse/Unyson/issues/1347
 */
require dirname(__FILE__) .'/backend-option-design-default.php';
